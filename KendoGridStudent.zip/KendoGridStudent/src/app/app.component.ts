import { Component, OnInit, ViewChild } from '@angular/core';
import { DataBindingDirective } from '@progress/kendo-angular-grid';
import { process } from "@progress/kendo-data-query";
//import { StudentService } from '../../Student/Student.service';
import { students } from './student;

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'KendoUIAngular14';

  @ViewChild(DataBindingDirective) dataBinding!: DataBindingDirective;
  public gridData: unknown[] = students;
  public gridView!: unknown[];

  public mySelection: string[] = [];

  //inject http service for student service and make a get call for students
  public ngOnInit(): void {
    this.gridView = this.gridData;
  }
  
  public onFilter(input: Event): void {
    const inputValue = (input.target as HTMLInputElement).value;

    this.gridView = process(this.gridData, {
      filter: {
        logic: "or",
        filters: [
          {
            field: "name",
            operator: "contains",
            value: inputValue,
          },
          {
            field: "age",
            operator: "contains",
            value: inputValue,
          },
          {
            field: "hobbies",
            operator: "contains",
            value: inputValue,
          },          
        ],
      },
    }).data;

    this.dataBinding.skip = 0;
  }
}

