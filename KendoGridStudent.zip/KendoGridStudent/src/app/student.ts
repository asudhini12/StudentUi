export const students = [   
    {  
        id:1,
        name: "Alice",  
        age: "25",  
        hobbies: "Swimming and Dancing"
    }, {  
        id:2,
      name: "Bob",  
      age: "27",  
      hobbies: "Painting and Reading"  
    },
]